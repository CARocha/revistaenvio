$(function(){
    $('#wraper').corner('round 2px');
    $('h1').jfontsize({sizeChange: 3});
    SyntaxHighlighter.all();
})